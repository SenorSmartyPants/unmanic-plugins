# Ignore files recently modified

plugin for [Unmanic](https://github.com/Unmanic)
