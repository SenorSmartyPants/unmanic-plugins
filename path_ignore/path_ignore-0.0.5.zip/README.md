# Path Ignore

plugin for [Unmanic](https://github.com/Unmanic)
