# Ignore files over size

plugin for [Unmanic](https://github.com/Unmanic)
